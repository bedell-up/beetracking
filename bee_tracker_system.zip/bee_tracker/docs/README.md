# Bombus vosnesenskii AprilTag Tracker
### University of Portland — SLUG / Pollinator Research

## Quick Start

```bash
# 1. Clone on each Pi
git clone https://github.com/bedell-up/beetracking.git
cd beetracking

# 2. Install dependencies
bash scripts/setup.sh

# 3. Generate and print tags (run on a laptop with a printer)
python3 scripts/generate_tags.py --count 64 --size 5

# 4. Run detector (replace A with your site ID)
python3 scripts/detect.py --site A

# 5. Analyze results (after collecting data from all sites)
python3 scripts/analyze.py
```

## System Overview

- **Tags**: AprilTag 36h11, printed at 5mm, glued to bee thorax
- **Detection**: OpenCV aruco on Raspberry Pi 5 with IMX219 120° camera
- **Logging**: Timestamped CSV per site + verification images
- **Analysis**: Movement matrix, transit times, draft publication text

## Hardware (per station)
- Raspberry Pi 5 1GB
- Waveshare IMX219 120° FOV Camera
- Pi 5 Camera Cable 500mm
- Samsung PRO Endurance 64GB MicroSD
- Anker PowerCore 10K power bank
- IP65 hinged weatherproof box
- PATIKIL 15.7" gooseneck (1/4"-20)
- Ruthex 1/4"-20 brass heat-set insert

## File Structure
```
beetracking/
├── scripts/
│   ├── detect.py          # Run on each Pi station
│   ├── generate_tags.py   # Run on laptop to print tags
│   ├── analyze.py         # Run after fieldwork
│   └── setup.sh           # Run once per Pi
├── data/                  # Auto-created, holds CSVs
├── tags/                  # Auto-created, holds tag PDFs
└── docs/
    └── README.md
```

## Contact
bedell@up.edu — University of Portland Biology Department
