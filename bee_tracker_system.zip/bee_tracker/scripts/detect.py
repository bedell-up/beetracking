"""
Bee AprilTag Detector - Raspberry Pi Camera Script
===================================================
Bombus vosnesenskii movement tracking
University of Portland - SLUG / Pollinator Research

Usage:
    python detect.py --site A
    python detect.py --site B

Logs detections to: ../data/site_A_detections.csv
Also saves a small verification image for every new detection.

Requirements:
    pip install picamera2 opencv-contrib-python numpy
"""

import cv2
import numpy as np
import csv
import os
import time
import argparse
from datetime import datetime
from picamera2 import Picamera2

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

ARUCO_DICT        = cv2.aruco.DICT_APRILTAG_36h11
MIN_CORNER_DISTANCE = 10
COOLDOWN_SECONDS  = 10
FRAME_WIDTH       = 1280   # 720p for Pi 5 efficiency
FRAME_HEIGHT      = 720
FRAME_SKIP        = 3      # Process every 4th frame

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
DATA_DIR   = os.path.join(BASE_DIR, "..", "data")
VERIFY_DIR = os.path.join(DATA_DIR, "verification_images")


def setup_dirs(site):
    os.makedirs(DATA_DIR, exist_ok=True)
    verify_path = os.path.join(VERIFY_DIR, f"site_{site}")
    os.makedirs(verify_path, exist_ok=True)
    return verify_path


def get_csv_path(site):
    return os.path.join(DATA_DIR, f"site_{site}_detections.csv")


def init_csv(csv_path, site):
    if not os.path.exists(csv_path):
        with open(csv_path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["tag_id", "site", "date", "time",
                             "timestamp_unix", "confidence",
                             "frame_width", "frame_height"])
        print(f"[INIT] Created new log: {csv_path}")
    else:
        print(f"[INIT] Appending to existing log: {csv_path}")


def setup_camera():
    cam = Picamera2()
    config = cam.create_video_configuration(
        main={"size": (FRAME_WIDTH, FRAME_HEIGHT), "format": "RGB888"},
        controls={
            "ExposureTime": 2000,
            "AnalogueGain": 2.0,
            "AeEnable": True,
            "AwbEnable": True,
        }
    )
    cam.configure(config)
    cam.start()
    time.sleep(2)
    print(f"[CAMERA] Started at {FRAME_WIDTH}x{FRAME_HEIGHT}")
    return cam


def setup_detector():
    aruco_dict = cv2.aruco.getPredefinedDictionary(ARUCO_DICT)
    params = cv2.aruco.DetectorParameters()
    params.adaptiveThreshWinSizeMin  = 3
    params.adaptiveThreshWinSizeMax  = 23
    params.adaptiveThreshWinSizeStep = 4
    params.minMarkerPerimeterRate    = 0.01
    params.maxMarkerPerimeterRate    = 0.3
    params.polygonalApproxAccuracyRate = 0.05
    params.minCornerDistanceRate     = 0.01
    params.errorCorrectionRate       = 0.9
    detector = cv2.aruco.ArucoDetector(aruco_dict, params)
    print("[DETECTOR] AprilTag 36h11 detector ready")
    return detector


def log_detection(csv_path, tag_id, site, confidence):
    now = datetime.now()
    with open(csv_path, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            tag_id, site,
            now.strftime("%Y-%m-%d"),
            now.strftime("%H:%M:%S"),
            now.timestamp(),
            f"{confidence:.3f}",
            FRAME_WIDTH, FRAME_HEIGHT
        ])
    print(f"  ✓ LOGGED → Tag {tag_id:>4} | Site {site} | {now.strftime('%H:%M:%S')}")


def save_verification_image(frame, corners, tag_id, site, verify_dir):
    try:
        pts = corners[0].astype(int)
        x_min, y_min = pts.min(axis=0) - 20
        x_max, y_max = pts.max(axis=0) + 20
        x_min = max(0, x_min); y_min = max(0, y_min)
        x_max = min(FRAME_WIDTH, x_max); y_max = min(FRAME_HEIGHT, y_max)
        crop = frame[y_min:y_max, x_min:x_max]
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(verify_dir, f"tag{tag_id:04d}_{ts}.jpg")
        cv2.imwrite(filepath, cv2.cvtColor(crop, cv2.COLOR_RGB2BGR))
    except Exception as e:
        print(f"  [WARN] Could not save verification image: {e}")


def run_detection(site):
    verify_dir = setup_dirs(site)
    csv_path   = get_csv_path(site)
    init_csv(csv_path, site)
    cam        = setup_camera()
    detector   = setup_detector()
    last_seen  = {}

    print(f"\n[RUNNING] Site {site} detection active. Press Ctrl+C to stop.\n")

    frame_count = 0
    try:
        while True:
            frame = cam.capture_array()
            frame_count += 1
            if frame_count % (FRAME_SKIP + 1) != 0:
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
            corners, ids, _ = detector.detectMarkers(gray)

            if ids is not None:
                for i, tag_id in enumerate(ids.flatten()):
                    tag_corners = corners[i]
                    side_length = np.linalg.norm(
                        tag_corners[0][0] - tag_corners[0][1])
                    if side_length < MIN_CORNER_DISTANCE:
                        continue
                    confidence = min(side_length / 100.0, 1.0)
                    now_unix = time.time()
                    if tag_id in last_seen:
                        if now_unix - last_seen[tag_id] < COOLDOWN_SECONDS:
                            continue
                    last_seen[tag_id] = now_unix
                    print(f"  → Tag {tag_id:>4} detected (size: {side_length:.1f}px)")
                    log_detection(csv_path, tag_id, site, confidence)
                    save_verification_image(frame, tag_corners, tag_id, site, verify_dir)

    except KeyboardInterrupt:
        print(f"\n[STOPPED] Site {site} session ended. Data saved to {csv_path}")
    finally:
        cam.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bee AprilTag Detector")
    parser.add_argument("--site", required=True,
                        help="Site identifier e.g. A, B, C ...")
    args = parser.parse_args()
    run_detection(args.site)
