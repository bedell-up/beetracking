#!/bin/bash
# Bee Tracker - Raspberry Pi Setup Script
# Run once on each Pi after first boot
# Usage: bash scripts/setup.sh

echo "=== Bee Tracker Setup ==="

sudo apt-get update -y
sudo apt-get upgrade -y
sudo apt-get install -y python3-pip python3-picamera2 python3-libcamera git

pip3 install opencv-contrib-python numpy pandas reportlab Pillow --break-system-packages

# Create data directories
mkdir -p ~/beetracking/data/verification_images
mkdir -p ~/beetracking/tags

echo ""
echo "=== Setup complete ==="
echo ""
echo "To run detector:    python3 scripts/detect.py --site A"
echo "To generate tags:   python3 scripts/generate_tags.py"
echo "To analyze data:    python3 scripts/analyze.py"
echo ""
echo "To auto-start on boot, run:"
echo "  crontab -e"
echo "  Add: @reboot sleep 15 && python3 /home/pi/beetracking/scripts/detect.py --site A >> /home/pi/beetracking/data/log.txt 2>&1"
