"""
AprilTag Sheet Generator for Bee Tracking
==========================================
Generates a printable PDF sheet of unique AprilTags
sized for Bombus vosnesenskii thorax attachment.

Usage:
    python generate_tags.py --count 64 --size 5

Output:
    ../tags/apriltags_5mm.pdf   — print at 100% scale
    ../tags/tag_manifest.csv    — fill in field for each bee

Requirements:
    pip install opencv-contrib-python numpy reportlab Pillow
"""

import cv2
import numpy as np
import csv
import os
import argparse

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
TAGS_DIR  = os.path.join(BASE_DIR, "..", "tags")
ARUCO_DICT = cv2.aruco.DICT_APRILTAG_36h11


def generate_tag_image(tag_id, size_px):
    aruco_dict = cv2.aruco.getPredefinedDictionary(ARUCO_DICT)
    tag_img = np.zeros((size_px, size_px), dtype=np.uint8)
    return cv2.aruco.generateImageMarker(aruco_dict, tag_id, size_px, tag_img, 1)


def generate_pdf(count, size_mm):
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas as rl_canvas
        from reportlab.lib.utils import ImageReader
        from PIL import Image
        import io
    except ImportError:
        print("[ERROR] Run: pip install reportlab Pillow")
        return

    os.makedirs(TAGS_DIR, exist_ok=True)

    page_w, page_h = A4
    margin       = 10 * mm
    label_height = 4 * mm
    cell_size    = size_mm * mm + 2 * mm
    row_height   = cell_size + label_height + 1 * mm
    cols         = int((page_w - 2 * margin) / cell_size)
    rows         = int((page_h - 2 * margin) / row_height)
    per_page     = cols * rows

    pdf_path = os.path.join(TAGS_DIR, f"apriltags_{size_mm}mm.pdf")
    c = rl_canvas.Canvas(pdf_path, pagesize=A4)
    c.setFont("Helvetica", 5)

    tag_id = 0
    page   = 0

    while tag_id < count:
        if tag_id > 0 and tag_id % per_page == 0:
            c.showPage()
            page += 1
            c.setFont("Helvetica", 5)

        pos   = tag_id % per_page
        col   = pos % cols
        row   = pos // cols
        x     = margin + col * cell_size
        y     = page_h - margin - (row + 1) * row_height

        tag_img  = generate_tag_image(tag_id, 200)
        pil_img  = Image.fromarray(tag_img).convert("RGB")
        buf      = io.BytesIO()
        pil_img.save(buf, format="PNG")
        buf.seek(0)

        c.setFillColorRGB(1, 1, 1)
        c.rect(x, y, cell_size, cell_size + label_height, fill=1, stroke=0)
        c.drawImage(ImageReader(buf), x + 1*mm, y + label_height + 0.5*mm,
                    width=size_mm*mm, height=size_mm*mm)
        c.setFillColorRGB(0, 0, 0)
        c.drawCentredString(x + cell_size/2, y + 1*mm, f"ID:{tag_id:03d}")
        tag_id += 1

    # Instructions page
    c.showPage()
    c.setFont("Helvetica-Bold", 12)
    c.drawString(30, 800, "Bee AprilTag Application Instructions")
    c.setFont("Helvetica", 10)
    instructions = [
        f"1. Print at EXACTLY 100% scale. Each tag should be {size_mm}mm x {size_mm}mm.",
        "2. Cut out tags keeping the white border.",
        "3. Chill bee on ice pack (~90 seconds) until motionless.",
        "4. Apply tiny superglue dot to tag. Press onto dorsal thorax. Hold 10 sec.",
        "5. Record tag ID in tag_manifest.csv. Release bee. Observe 5 min.",
        "6. Tag ID maps to a unique individual — never reuse IDs.",
    ]
    y = 775
    for line in instructions:
        c.drawString(30, y, line)
        y -= 18

    c.save()
    print(f"[PDF] Saved → {pdf_path}  ({count} tags, {size_mm}mm)")


def generate_manifest(count):
    os.makedirs(TAGS_DIR, exist_ok=True)
    manifest_path = os.path.join(TAGS_DIR, "tag_manifest.csv")
    with open(manifest_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["tag_id", "capture_site", "capture_date",
                         "capture_time", "bee_sex", "bee_size_estimate", "notes"])
        for tag_id in range(count):
            writer.writerow([tag_id, "", "", "", "", "", ""])
    print(f"[MANIFEST] Saved → {manifest_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=64)
    parser.add_argument("--size",  type=int, default=5)
    args = parser.parse_args()
    print(f"Generating {args.count} tags at {args.size}mm...")
    generate_pdf(args.count, args.size)
    generate_manifest(args.count)
    print("Done. Print PDF at 100% scale and verify size with a ruler.")
