"""
Bee Movement Analysis Script
==============================
Reads detection logs from all sites and produces:
  1. Movement summary — bees confirmed at multiple sites
  2. Per-site visit counts
  3. Inter-site transit times
  4. Draft publication results text

Usage:
    python analyze.py

Input:  ../data/site_*_detections.csv
Output: ../data/analysis_results.csv
        ../data/movement_summary.txt

Requirements:
    pip install pandas
"""

import pandas as pd
import os
import glob
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "..", "data")
TAGS_DIR = os.path.join(BASE_DIR, "..", "tags")


def load_data():
    pattern = os.path.join(DATA_DIR, "site_*_detections.csv")
    files   = glob.glob(pattern)
    if not files:
        print("[ERROR] No detection CSV files found in data/")
        return None
    dfs = []
    for f in sorted(files):
        df = pd.read_csv(f)
        df["timestamp"] = pd.to_datetime(df["date"] + " " + df["time"])
        dfs.append(df)
        print(f"[LOAD] {os.path.basename(f)}: {len(df)} detections")
    combined = pd.concat(dfs, ignore_index=True).sort_values("timestamp").reset_index(drop=True)
    print(f"[LOAD] Total: {len(combined)} detections across {len(files)} sites")
    return combined


def load_manifest():
    path = os.path.join(TAGS_DIR, "tag_manifest.csv")
    if os.path.exists(path):
        df = pd.read_csv(path)
        return df[df["capture_date"] != ""]
    return None


def analyze(combined, manifest=None):
    site_counts = combined.groupby(["tag_id", "site"]).size().unstack(fill_value=0)
    sites = sorted(combined["site"].unique())

    for site in sites:
        if site not in site_counts.columns:
            site_counts[site] = 0

    site_counts.columns = [f"visits_{s}" for s in site_counts.columns]

    seen_cols = []
    for site in sites:
        col = f"seen_at_{site}"
        site_counts[col] = site_counts[f"visits_{site}"] > 0
        seen_cols.append(col)

    site_counts["sites_visited"] = site_counts[seen_cols].sum(axis=1)
    site_counts["moved_between_sites"] = site_counts["sites_visited"] > 1
    site_counts["site_fidelity"] = site_counts.apply(
        lambda r: "Multiple" if r["moved_between_sites"]
        else next((s for s in sites if r[f"seen_at_{s}"]), "Unknown"),
        axis=1
    )

    first_last = combined.groupby("tag_id").agg(
        first_detection=("timestamp", "min"),
        last_detection=("timestamp", "max"),
        total_detections=("tag_id", "count")
    )
    summary = site_counts.join(first_last)

    if manifest is not None:
        m = manifest.set_index("tag_id")[
            ["capture_site", "capture_date", "bee_sex", "notes"]]
        summary = summary.join(m, how="left")

    # Inter-site movements
    movers = summary[summary["moved_between_sites"]].index.tolist()
    inter_site_times = []
    for tag_id in movers:
        bee = combined[combined["tag_id"] == tag_id].sort_values("timestamp")
        changes = bee[bee["site"] != bee["site"].shift()]
        for i in range(len(changes) - 1):
            t1 = changes.iloc[i]["timestamp"]
            t2 = changes.iloc[i+1]["timestamp"]
            inter_site_times.append({
                "tag_id": tag_id,
                "from_site": changes.iloc[i]["site"],
                "to_site":   changes.iloc[i+1]["site"],
                "elapsed_minutes": round((t2-t1).total_seconds()/60, 1)
            })

    inter_df = pd.DataFrame(inter_site_times) if inter_site_times else pd.DataFrame()
    return {"summary": summary, "inter_site_movements": inter_df, "sites": sites}


def print_report(results, combined):
    summary = results["summary"]
    inter   = results["inter_site_movements"]
    sites   = results["sites"]

    total  = len(summary)
    movers = summary["moved_between_sites"].sum()

    print("\n" + "═"*60)
    print("  BEE MOVEMENT ANALYSIS REPORT")
    print(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("═"*60)
    print(f"\n  Total unique tagged bees : {total}")
    print(f"  Detected at multiple sites: {movers}  ({100*movers/total:.1f}%)")
    print(f"\n  Total detection events   : {len(combined)}")
    for site in sites:
        n = (combined["site"] == site).sum()
        print(f"  Site {site} events           : {n}")

    if not inter.empty:
        print(f"\n  Inter-site movements     : {len(inter)}")
        print(f"  Median transit (min)     : {inter['elapsed_minutes'].median():.1f}")
        print(f"  Fastest transit (min)    : {inter['elapsed_minutes'].min():.1f}")

    pub_text = f"""
{'─'*60}
DRAFT RESULTS TEXT
{'─'*60}
Of {total} individually tagged Bombus vosnesenskii workers
detected across {len(sites)} study sites, {movers} individuals ({100*movers/total:.1f}%)
were recorded at more than one site, confirming inter-site
movement across the ~0.25-mile corridor with approximately
180 ft of elevation change.
"""
    if not inter.empty:
        pub_text += f"""
Inter-site transit times ranged from {inter['elapsed_minutes'].min():.1f} to
{inter['elapsed_minutes'].max():.1f} minutes (median: {inter['elapsed_minutes'].median():.1f} min,
n={len(inter)} recorded movements).
"""
    pub_text += "─"*60 + "\n"
    print(pub_text)
    return pub_text


def save_outputs(results, pub_text):
    os.makedirs(DATA_DIR, exist_ok=True)
    results["summary"].to_csv(os.path.join(DATA_DIR, "analysis_results.csv"))
    print(f"[SAVED] analysis_results.csv")
    if not results["inter_site_movements"].empty:
        results["inter_site_movements"].to_csv(
            os.path.join(DATA_DIR, "inter_site_movements.csv"), index=False)
        print(f"[SAVED] inter_site_movements.csv")
    with open(os.path.join(DATA_DIR, "movement_summary.txt"), "w") as f:
        f.write(pub_text)
    print(f"[SAVED] movement_summary.txt")


if __name__ == "__main__":
    combined = load_data()
    if combined is None:
        exit(1)
    manifest = load_manifest()
    results  = analyze(combined, manifest)
    pub_text = print_report(results, combined)
    save_outputs(results, pub_text)
